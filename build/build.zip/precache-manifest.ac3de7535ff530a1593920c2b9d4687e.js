self.__precacheManifest = [
  {
    "revision": "19ea7dc28e160b2929fc",
    "url": "/static/css/main.aec81f06.chunk.css"
  },
  {
    "revision": "19ea7dc28e160b2929fc",
    "url": "/static/js/main.61ecc85b.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "06be6c4fcb4692a4c703",
    "url": "/static/js/2.4b16d074.chunk.js"
  },
  {
    "revision": "3032ef1d5751619b54b884fc062265f5",
    "url": "/static/media/aleber.3032ef1d.jpg"
  },
  {
    "revision": "70a57c09bab773d37ebef996eb333368",
    "url": "/static/media/link_shortener.70a57c09.jpg"
  },
  {
    "revision": "8a966d2824d2b9d542786f78b40cd20d",
    "url": "/static/media/react_pizza.8a966d28.jpg"
  },
  {
    "revision": "6d512eabf9642809c52013ea8fda89cf",
    "url": "/static/media/social_network.6d512eab.jpg"
  },
  {
    "revision": "72c7fb085d8d1c528327643b23e3faa0",
    "url": "/static/media/todo_list.72c7fb08.jpg"
  },
  {
    "revision": "0b65007e0fbd55ed3e008e1ac91e1d11",
    "url": "/static/media/simple_chat.0b65007e.jpg"
  },
  {
    "revision": "0a22dd6b729c047a23df057688a97175",
    "url": "/static/media/farizda_cv.0a22dd6b.jpg"
  },
  {
    "revision": "f80b78d42c265011ba11b7b880fe7905",
    "url": "/static/media/yeti_calc.f80b78d4.jpg"
  },
  {
    "revision": "62f40fdb55c6216c5e88bb5f64310ea8",
    "url": "/static/media/tabs_gallery.62f40fdb.jpg"
  },
  {
    "revision": "98ad41a343806a7d429c16d2844b0737",
    "url": "/static/media/screen_keyboard.98ad41a3.jpg"
  },
  {
    "revision": "f68725fbdd301b2e4a7ef60d8e7f8c6b",
    "url": "/static/media/mega_calc.f68725fb.jpg"
  },
  {
    "revision": "688652085ecc8ec43b8b487dfbc6e6b4",
    "url": "/static/media/yeti_spb.68865208.jpg"
  },
  {
    "revision": "533a18c0426816acd5381b128a83d49d",
    "url": "/static/media/aquasklad.533a18c0.jpg"
  },
  {
    "revision": "62ac0b85940895ded10b9d58d31f0af3",
    "url": "/static/media/vodazona.62ac0b85.jpg"
  },
  {
    "revision": "a004b57ba68598ef24f53618e463e00e",
    "url": "/static/media/humoraf.a004b57b.jpg"
  },
  {
    "revision": "b89e5da215b31233f5e0fdc62a3089d1",
    "url": "/static/media/gurmanfresh.b89e5da2.jpg"
  },
  {
    "revision": "80249514b4dec875979004982a0abe75",
    "url": "/static/media/aquatrol.80249514.jpg"
  },
  {
    "revision": "28de22839adfc3f72ca7e44f59106244",
    "url": "/static/media/iam.28de2283.png"
  },
  {
    "revision": "15a5f3d81716df62006ba91e6df99a6c",
    "url": "/static/media/whatsapp.15a5f3d8.svg"
  },
  {
    "revision": "bf079929845ab2bede53a5b2a441ce9e",
    "url": "/static/media/telegram.bf079929.svg"
  },
  {
    "revision": "44b38f36c26f9aca533a7115ce9b019e",
    "url": "/static/media/skype.44b38f36.svg"
  },
  {
    "revision": "e3a95a146607c625f8df7e5bf93019a5",
    "url": "/static/media/gmail.e3a95a14.svg"
  },
  {
    "revision": "dcda6bebd29eb8720acad8f26a29c408",
    "url": "/static/media/Montserrat-Italic.dcda6beb.woff"
  },
  {
    "revision": "6c8807219b0ecffdf96122b80df3e62c",
    "url": "/static/media/Montserrat-Regular.6c880721.woff2"
  },
  {
    "revision": "c0b8804ae85213c9194816da945db150",
    "url": "/static/media/Montserrat-Regular.c0b8804a.woff"
  },
  {
    "revision": "43a841b1ec910ba2ecce5ee89515f462",
    "url": "/static/media/Montserrat-MediumItalic.43a841b1.woff2"
  },
  {
    "revision": "82168e0b17675a8bcb2930cf5c5a05da",
    "url": "/static/media/Montserrat-Italic.82168e0b.woff2"
  },
  {
    "revision": "5eb647be12235c37d0b5ac801a8fde92",
    "url": "/static/media/Montserrat-MediumItalic.5eb647be.woff"
  },
  {
    "revision": "72aebf4516ddcbc7634c4640fb6f9a90",
    "url": "/static/media/Montserrat-Medium.72aebf45.woff"
  },
  {
    "revision": "5fec409400acb31e906e1b6c074292b8",
    "url": "/static/media/Montserrat-SemiBoldItalic.5fec4094.woff2"
  },
  {
    "revision": "4193cb373574474bd262f0cada40c68e",
    "url": "/static/media/Montserrat-Medium.4193cb37.woff2"
  },
  {
    "revision": "f4103669740e1258103e7fee7bfafbc1",
    "url": "/static/media/Montserrat-SemiBold.f4103669.woff"
  },
  {
    "revision": "7b1d2334374bfee9ee4cf18d31385882",
    "url": "/static/media/Montserrat-SemiBoldItalic.7b1d2334.woff"
  },
  {
    "revision": "c74260cde1a16b48febba358704ac4b6",
    "url": "/static/media/Montserrat-SemiBold.c74260cd.woff2"
  },
  {
    "revision": "084b126a8532a1c9a27374d0996104db",
    "url": "/index.html"
  }
];